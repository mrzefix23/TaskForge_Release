package com.taskforge.exceptions;

public class UpdateProjectException extends RuntimeException {
    public UpdateProjectException(String message) {
        super(message);
    }
}
