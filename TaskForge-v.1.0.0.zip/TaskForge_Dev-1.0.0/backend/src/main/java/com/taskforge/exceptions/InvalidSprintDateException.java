package com.taskforge.exceptions;

public class InvalidSprintDateException extends RuntimeException {
    public InvalidSprintDateException(String message) {
        super(message);
    }
}
