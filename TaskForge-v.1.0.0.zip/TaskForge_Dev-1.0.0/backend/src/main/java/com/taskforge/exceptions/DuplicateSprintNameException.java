package com.taskforge.exceptions;

public class DuplicateSprintNameException extends RuntimeException {
    public DuplicateSprintNameException(String message) {
        super(message);
    }
}
