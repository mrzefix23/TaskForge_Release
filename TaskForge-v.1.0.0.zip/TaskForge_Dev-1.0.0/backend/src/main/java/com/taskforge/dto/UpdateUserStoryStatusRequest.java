package com.taskforge.dto;

import lombok.Data;

@Data
public class UpdateUserStoryStatusRequest {
    private String status;
}
