package com.taskforge.exceptions;

public class ProjectSuppressionException extends RuntimeException {
    public ProjectSuppressionException(String message) {
        super(message);
    }
}
